﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using DomainModel;
using DomainModel.Entities.LeilaoAggregate;

namespace WcfService
{
    [ServiceContract]
    public interface IServicoLeilaoWCF
    {
        [OperationContract]
        void InicializarEntidades();

        [OperationContract]
        List<Titulo> GetTitulos();

        [OperationContract]
        void CadastrarLeilao(Leilao novoLeilao);
    }
}
