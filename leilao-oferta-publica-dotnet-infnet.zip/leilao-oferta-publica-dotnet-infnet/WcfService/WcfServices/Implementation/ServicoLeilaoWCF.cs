﻿using DomainModel;
using DomainModel.Entities.LeilaoAggregate;
using DomainModel.Interfaces.Repositories;
using DomainModel.Interfaces.Services;
using DomainService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WcfService
{
    public class ServicoLeilaoWCF : IServicoLeilaoWCF
    {
        IServicoInicializarEntidades servicoInicializarEntidades = new ServicoInicializarEntidade();
        IServicoCadastrarLeilao servicoCadastrarLeilao = new ServicoCadastrarLeilao();

        public void InicializarEntidades()
        {
            servicoInicializarEntidades.InicializarEntidades();
        }

        public List<Titulo> GetTitulos()
        {
            return servicoCadastrarLeilao.GetTitulos();
        }

        public void CadastrarLeilao(Leilao novoLeilao)
        {
            servicoCadastrarLeilao.CadastrarLeilao(novoLeilao);
        }
    }
}