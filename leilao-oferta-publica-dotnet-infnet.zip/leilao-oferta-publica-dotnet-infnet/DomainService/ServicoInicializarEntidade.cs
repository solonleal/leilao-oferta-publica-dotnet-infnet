﻿using Data;
using DomainModel;
using DomainModel.Entities;
using DomainModel.Interfaces.Repositories;
using DomainModel.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainService
{
    public class ServicoInicializarEntidade : IServicoInicializarEntidades
    {
        ITituloRepository tituloRepository = new TituloRepository();

        public void InicializarEntidades()
        {
            CriarTitulos();
        }

        private void CriarTitulos()
        {
            TipoTitulo novoTipoTitulo1 = new TipoTitulo("LTN", TipoPagamentoEnum.PRE_RENDIMENTO);
            TipoTitulo novoTipoTitulo2 = new TipoTitulo("LFT", TipoPagamentoEnum.PRE_RENDIMENTO);
            TipoTitulo novoTipoTitulo3 = new TipoTitulo("NTN-B", TipoPagamentoEnum.POS_RENDIMENTO);

            Titulo novoTitulo1 = new Titulo("100000", new DateTime(2018, 7, 15), novoTipoTitulo1);
            Titulo novoTitulo2 = new Titulo("100000", new DateTime(2022, 7, 15), novoTipoTitulo1);
            Titulo novoTitulo3 = new Titulo("100000", new DateTime(2025, 7, 15), novoTipoTitulo1);

            Titulo novoTitulo4 = new Titulo("333333", new DateTime(2020, 1, 15), novoTipoTitulo2);
            Titulo novoTitulo5 = new Titulo("333333", new DateTime(2025, 1, 15), novoTipoTitulo2);
            Titulo novoTitulo6 = new Titulo("333333", new DateTime(2030, 1, 15), novoTipoTitulo2);

            Titulo novoTitulo7 = new Titulo("999999", new DateTime(2040, 10, 10), novoTipoTitulo3);
            Titulo novoTitulo8 = new Titulo("999999", new DateTime(2045, 10, 10), novoTipoTitulo3);
            Titulo novoTitulo9 = new Titulo("999999", new DateTime(2050, 10, 10), novoTipoTitulo3);

            tituloRepository.Create(novoTitulo1);
            tituloRepository.Create(novoTitulo2);
            tituloRepository.Create(novoTitulo3);
            tituloRepository.Create(novoTitulo4);
            tituloRepository.Create(novoTitulo5);
            tituloRepository.Create(novoTitulo6);
            tituloRepository.Create(novoTitulo7);
            tituloRepository.Create(novoTitulo8);
            tituloRepository.Create(novoTitulo9);
        }
    }
}
