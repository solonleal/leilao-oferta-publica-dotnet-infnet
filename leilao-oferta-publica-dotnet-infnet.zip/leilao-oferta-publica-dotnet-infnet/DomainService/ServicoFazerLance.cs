﻿using Data.Repositories;
using DomainModel.Entities.Instituicao;
using DomainModel.Entities.LeilaoAggregate;
using DomainModel.Interfaces.Repositories;
using DomainModel.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainService
{
    public class ServicoFazerLance : IServicoFazerLance
    {
        IInstituicaoRepository instituicaoRepository = new InstituicaoRepository();
        ILeilaoRepository leilaoRepository = new LeilaoRepository();

        public List<Instituicao> GetInstituicoes()
        {
            return instituicaoRepository.GetAll().ToList();
        }

        public List<LeilaoOferta> GetOfertas()
        {
            Leilao leilao = leilaoRepository.GetAll().First();
            return leilao.Ofertas;
        }
    }
}
