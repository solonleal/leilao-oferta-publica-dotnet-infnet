﻿using Data.Repositories;
using DomainModel.Entities.Instituicao;
using DomainModel.Interfaces.Repositories;
using DomainModel.Interfaces.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainService
{
    public class ServicoFazerLance : IServicoFazerLance
    {
        IInstituicaoRepository instituicaoRepository = new InstituicaoRepository();

        public List<Instituicao> GetInstituicoes()
        {
            return instituicaoRepository.GetAll().ToList();
        }
    }
}
