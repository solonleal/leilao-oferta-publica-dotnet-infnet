﻿using DomainModel.Interfaces.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DomainModel;
using Data;
using DomainModel.Entities.LeilaoAggregate;
using Data.Repositories;

namespace DomainService
{
    public class ServicoCadastrarLeilao : IServicoCadastrarLeilao
    {
        ITituloRepository tituloRepository = new TituloRepository();
        ILeilaoRepository leilaoRepository = new LeilaoRepository();

        public List<Titulo> GetTitulos()
        {
            return tituloRepository.GetAll().ToList();
        }

        public void CadastrarLeilao(Leilao leilao)
        {
            leilaoRepository.Create(leilao);
        }
    }
}