﻿using DomainModel.Interfaces.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DomainModel;
using Data;

namespace DomainService
{
    public class ServicoCadastrarLeilao : IServicoCadastrarLeilao
    {
        public ITituloRepository tituloRepository = new TituloRepository();

        public List<Titulo> GetTitulos()
        {
            return tituloRepository.GetAll().ToList();
        }
    }
}