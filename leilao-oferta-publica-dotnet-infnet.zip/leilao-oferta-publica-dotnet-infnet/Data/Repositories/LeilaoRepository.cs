﻿using DomainModel.Entities.LeilaoAggregate;
using DomainModel.Interfaces.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Repositories
{
    public class LeilaoRepository : RepositoryBase<Leilao>, ILeilaoRepository
    {
    }
}
