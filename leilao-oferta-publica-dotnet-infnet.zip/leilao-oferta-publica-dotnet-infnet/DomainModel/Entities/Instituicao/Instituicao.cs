﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainModel.Entities.Instituicao
{
    public class Instituicao : TEntity
    {
        public string Nome { get; set; }
        public string Isbp { get; set; }

        public Instituicao(string novoNome, string novoIspb)
        {
            this.Nome = novoNome;
            this.Isbp = novoIspb;
        }
    }
}
