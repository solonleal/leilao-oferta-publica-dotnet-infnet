﻿using System.Runtime.Serialization;
using DomainModel.Entities.Instituicao;


namespace DomainModel.Entities.LeilaoAggregate
{
    [DataContract]
    public class Lance : TEntity
    {
        [DataMember]
        public int Instituicao { get; set; }
        [DataMember]
        public long Quantidade { get; set; }
        [DataMember]
        public decimal PrecoUnitario { get; set; }
    }
}