﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DomainModel.Entities.LeilaoAggregate
{
    [DataContract]
    public class LeilaoOferta : TEntity
    {
        [DataMember]
        public Titulo Titulo { get; set; }
        [DataMember]
        public long Quantidade { get; set; }
        [DataMember]
        public List<Lance> Lances { get; set; }

        public override string ToString()
        {
            return String.Format("{0} - {1}", Titulo.Name(), Quantidade);
        }
    }
}
