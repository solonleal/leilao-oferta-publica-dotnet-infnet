﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainModel.Entities.LeilaoAggregate
{
    public class LeilaoOferta : TEntity
    {
        public Titulo Titulo { get; set; }
        public long Quantidade { get; set; }

        public override string ToString()
        {
            return String.Format("{0} - {1}", Titulo.Name(), Quantidade);
        }
    }
}
