﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DomainModel.Entities.LeilaoAggregate
{
    [DataContract]
    public class Leilao : TEntity
    {
        [DataMember]
        public string Portaria { get; set; }
        [DataMember]
        public DateTime DataLeilao { get; set; }
        [DataMember]
        public List<LeilaoOferta> Ofertas { get; set; }
    }
}
