﻿using DomainModel.Entities.LeilaoAggregate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DomainModel.Entities.ResultadoLeilao
{
    [DataContract]
    public class ResultadoLeilaoLance : TEntity
    {
        [DataMember]
        public long QuantidadeAceita { get; set; }
        [DataMember]
        public decimal PrecoUnitario { get; set; }
        [DataMember]
        public Lance Lance { get; set; }
    }
}
