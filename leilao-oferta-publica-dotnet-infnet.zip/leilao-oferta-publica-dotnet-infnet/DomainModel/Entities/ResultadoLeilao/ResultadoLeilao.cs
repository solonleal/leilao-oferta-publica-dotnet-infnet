﻿using DomainModel.Entities.LeilaoAggregate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DomainModel.Entities.ResultadoLeilao
{
    [DataContract]
    public class ResultadoLeilao : TEntity
    {
        [DataMember]
        public LeilaoOferta Oferta { get; set; }
        [DataMember]
        public long QuantidadeRestante { get; set; }
        [DataMember]
        public List<ResultadoLeilaoLance> ResultadoLance { get; set; }
    }
}
