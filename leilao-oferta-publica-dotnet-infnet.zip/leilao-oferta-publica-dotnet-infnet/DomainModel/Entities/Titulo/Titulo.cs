﻿using DomainModel.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DomainModel
{
    [DataContract]
    public class Titulo : TEntity
    {
        [DataMember]
        public string Codigo { get; set; }
        [DataMember]
        public DateTime Vencimento { get; set; }
        [DataMember]
        public TipoTitulo TipoTitulo { get; set; }

        public Titulo(string novoCodigo, DateTime novoVencimento, TipoTitulo novoTipoTitulo)
        {
            this.Id = Guid.NewGuid();
            this.Codigo = novoCodigo;
            this.Vencimento = novoVencimento;
            this.TipoTitulo = novoTipoTitulo;
        }

        public string Name()
        {
            var dataFormatada = Vencimento.ToShortDateString();
            return String.Format("{0} {1} {2}", TipoTitulo.Sigla, Codigo, dataFormatada);
        }
    }
}
