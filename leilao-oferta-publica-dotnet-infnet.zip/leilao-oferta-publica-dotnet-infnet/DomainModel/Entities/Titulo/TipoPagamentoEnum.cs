﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DomainModel.Entities
{
    [DataContract]
    public enum TipoPagamentoEnum
    {
       PRE_RENDIMENTO,
       POS_RENDIMENTO
    }
}
