﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainModel.Entities
{
    public enum TipoPagamentoEnum
    {
       PRE_RENDIMENTO,
       POS_RENDIMENTO
    }
}
