﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DomainModel.Entities
{
    [DataContract]
    public class TipoTitulo
    {
        [DataMember]
        public string Sigla { get; set; }
        [DataMember]
        public TipoPagamentoEnum TipoPagamento { get; set; }

        public TipoTitulo(string novaSigla, TipoPagamentoEnum tpPagamento)
        {
            this.Sigla = novaSigla;
            this.TipoPagamento = tpPagamento;
        }
            
    }
}
