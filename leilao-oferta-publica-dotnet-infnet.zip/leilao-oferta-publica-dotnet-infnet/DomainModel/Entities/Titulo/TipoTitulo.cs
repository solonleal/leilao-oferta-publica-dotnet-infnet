﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainModel.Entities
{
    public class TipoTitulo
    {
        public string Sigla { get; set; }
        public TipoPagamentoEnum TipoPagamento { get; set; }

        public TipoTitulo(string novaSigla, TipoPagamentoEnum tpPagamento)
        {
            this.Sigla = novaSigla;
            this.TipoPagamento = tpPagamento;
        }
            
    }
}
