﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using WcfServiceApp;

namespace WindowsApp
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            InicializarEntidades();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new TelaInicial());
        }

        private static void InicializarEntidades()
        {
            var fabricaServicoRemoto = new FabricaServicoRemoto();

            var servicoRemoto = fabricaServicoRemoto.GetServicoLeilaoWCF();
            servicoRemoto.InicializarEntidades();

            fabricaServicoRemoto.CloseServicoLeilaoWCF();
        }
    }
}
