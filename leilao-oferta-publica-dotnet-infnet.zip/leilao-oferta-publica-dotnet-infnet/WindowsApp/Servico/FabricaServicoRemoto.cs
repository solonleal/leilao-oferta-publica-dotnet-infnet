﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WcfServiceApp;

namespace WindowsApp
{
    public class FabricaServicoRemoto : IFabricaServicoRemoto
    {
        IServicoLeilaoWCF servico;
        public IServicoLeilaoWCF GetServicoLeilaoWCF()
        {
            //            var servico = new ServicoLeilaoWCF();
            //            servico.Open();
            //            servico.InicializarEntidades();
            servico = new ServicoLeilaoWCF();

            return servico;
        }

        public void CloseServicoLeilaoWCF()
        {
            //            servico.Close();
        }
    }
}
