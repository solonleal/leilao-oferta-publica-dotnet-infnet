﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WcfServiceApp;

namespace WindowsApp
{
    public interface IFabricaServicoRemoto
    {
        IServicoLeilaoWCF GetServicoLeilaoWCF();

        void CloseServicoLeilaoWCF();
    }
}
