﻿namespace WindowsApp
{
    partial class AdicionarTituloLeilao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.quantidadeTitulo = new System.Windows.Forms.TextBox();
            this.lblQuantidadeTitulo = new System.Windows.Forms.Label();
            this.titulos = new System.Windows.Forms.ComboBox();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.btnAdicionarNovoTitulo = new System.Windows.Forms.Button();
            this.btnVoltarTelaInicial = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // quantidadeTitulo
            // 
            this.quantidadeTitulo.Location = new System.Drawing.Point(142, 165);
            this.quantidadeTitulo.Name = "quantidadeTitulo";
            this.quantidadeTitulo.Size = new System.Drawing.Size(168, 20);
            this.quantidadeTitulo.TabIndex = 0;
            // 
            // lblQuantidadeTitulo
            // 
            this.lblQuantidadeTitulo.AutoSize = true;
            this.lblQuantidadeTitulo.Location = new System.Drawing.Point(45, 168);
            this.lblQuantidadeTitulo.Name = "lblQuantidadeTitulo";
            this.lblQuantidadeTitulo.Size = new System.Drawing.Size(91, 13);
            this.lblQuantidadeTitulo.TabIndex = 1;
            this.lblQuantidadeTitulo.Text = "Quantidade Titulo";
            // 
            // titulos
            // 
            this.titulos.FormattingEnabled = true;
            this.titulos.Location = new System.Drawing.Point(142, 120);
            this.titulos.Name = "titulos";
            this.titulos.Size = new System.Drawing.Size(168, 21);
            this.titulos.TabIndex = 2;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Location = new System.Drawing.Point(103, 123);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(33, 13);
            this.lblTitulo.TabIndex = 3;
            this.lblTitulo.Text = "Titulo";
            // 
            // btnAdicionarNovoTitulo
            // 
            this.btnAdicionarNovoTitulo.Location = new System.Drawing.Point(118, 258);
            this.btnAdicionarNovoTitulo.Name = "btnAdicionarNovoTitulo";
            this.btnAdicionarNovoTitulo.Size = new System.Drawing.Size(168, 51);
            this.btnAdicionarNovoTitulo.TabIndex = 4;
            this.btnAdicionarNovoTitulo.Text = "Adicionar Novo Titulo";
            this.btnAdicionarNovoTitulo.UseVisualStyleBackColor = true;
            this.btnAdicionarNovoTitulo.Click += new System.EventHandler(this.btnAdicionarNovoTitulo_Click);
            // 
            // btnVoltarTelaInicial
            // 
            this.btnVoltarTelaInicial.Location = new System.Drawing.Point(251, 35);
            this.btnVoltarTelaInicial.Name = "btnVoltarTelaInicial";
            this.btnVoltarTelaInicial.Size = new System.Drawing.Size(59, 23);
            this.btnVoltarTelaInicial.TabIndex = 5;
            this.btnVoltarTelaInicial.Text = "Voltar";
            this.btnVoltarTelaInicial.UseVisualStyleBackColor = true;
            this.btnVoltarTelaInicial.Click += new System.EventHandler(this.btnVoltarTelaInicial_Click);
            // 
            // AdicionarTituloLeilao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(394, 379);
            this.Controls.Add(this.btnVoltarTelaInicial);
            this.Controls.Add(this.btnAdicionarNovoTitulo);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.titulos);
            this.Controls.Add(this.lblQuantidadeTitulo);
            this.Controls.Add(this.quantidadeTitulo);
            this.Name = "AdicionarTituloLeilao";
            this.Text = "Adicionar Novo Título ao Leilão";
            this.Load += new System.EventHandler(this.AdicionarTituloLeilao_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox quantidadeTitulo;
        private System.Windows.Forms.Label lblQuantidadeTitulo;
        private System.Windows.Forms.ComboBox titulos;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Button btnAdicionarNovoTitulo;
        private System.Windows.Forms.Button btnVoltarTelaInicial;
    }
}