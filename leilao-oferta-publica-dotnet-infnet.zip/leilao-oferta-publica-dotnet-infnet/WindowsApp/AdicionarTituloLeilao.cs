﻿using DomainModel;
using DomainModel.Entities;
using DomainModel.Entities.LeilaoAggregate;
using DomainModel.Interfaces.Repositories;
using DomainService;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsApp
{
    public partial class AdicionarTituloLeilao : Form
    {
        public List<LeilaoOferta> Ofertas { get; set; }

        public IServicoCadastrarLeilao servicoCadastrarLeilao = new ServicoCadastrarLeilao();

        public AdicionarTituloLeilao(List<LeilaoOferta> Ofertas)
        {
            InitializeComponent();

            this.Ofertas = Ofertas;
        }

        private void btnAdicionarNovoTitulo_Click(object sender, EventArgs e)
        {
            var titulo = ((ComboBoxItem)titulos.SelectedItem).Value;
            var quantidade = quantidadeTitulo.Text;

            var leilaoOferta = new LeilaoOferta();
            leilaoOferta.Quantidade = long.Parse(quantidade);
            leilaoOferta.Titulo = servicoCadastrarLeilao.GetTitulos().Find(t => t.Id == titulo);


            Ofertas.Add(leilaoOferta);

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnVoltarTelaInicial_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void AdicionarTituloLeilao_Load(object sender, EventArgs e)
        {
            var tituloList = servicoCadastrarLeilao.GetTitulos();

            foreach (var tituloItem in tituloList)
            {
                ComboBoxItem item = new ComboBoxItem(tituloItem.Name(), tituloItem.Id);
                titulos.Items.Add(item);
            }
        }

        public class ComboBoxItem
        {
            public string Text { get; set; }
            public Guid Value { get; set; }

            public ComboBoxItem(string text, Guid value)
            {
                Text = text;
                Value = value;
            }

            public override string ToString()
            {
                return Text;
            }
        }
    }
}
