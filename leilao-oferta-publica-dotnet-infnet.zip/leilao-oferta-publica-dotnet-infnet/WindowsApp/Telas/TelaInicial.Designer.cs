﻿namespace WindowsApp
{
    partial class TelaInicial
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cadastrarLeilao = new System.Windows.Forms.Button();
            this.fazerLance = new System.Windows.Forms.Button();
            this.finalizarLeilao = new System.Windows.Forms.Button();
            this.visualizarResultado = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cadastrarLeilao
            // 
            this.cadastrarLeilao.Location = new System.Drawing.Point(38, 46);
            this.cadastrarLeilao.Name = "cadastrarLeilao";
            this.cadastrarLeilao.Size = new System.Drawing.Size(680, 85);
            this.cadastrarLeilao.TabIndex = 0;
            this.cadastrarLeilao.Text = "Cadastrar Leilao";
            this.cadastrarLeilao.UseVisualStyleBackColor = true;
            this.cadastrarLeilao.Click += new System.EventHandler(this.cadastrarLeilao_Click);
            // 
            // fazerLance
            // 
            this.fazerLance.Location = new System.Drawing.Point(38, 156);
            this.fazerLance.Name = "fazerLance";
            this.fazerLance.Size = new System.Drawing.Size(679, 85);
            this.fazerLance.TabIndex = 2;
            this.fazerLance.Text = "Fazer Lance";
            this.fazerLance.UseVisualStyleBackColor = true;
            this.fazerLance.Click += new System.EventHandler(this.fazerLance_Click);
            // 
            // finalizarLeilao
            // 
            this.finalizarLeilao.Location = new System.Drawing.Point(38, 268);
            this.finalizarLeilao.Name = "finalizarLeilao";
            this.finalizarLeilao.Size = new System.Drawing.Size(679, 85);
            this.finalizarLeilao.TabIndex = 3;
            this.finalizarLeilao.Text = "Finalizar Leilão";
            this.finalizarLeilao.UseVisualStyleBackColor = true;
            this.finalizarLeilao.Click += new System.EventHandler(this.finalizarLeilao_Click);
            // 
            // visualizarResultado
            // 
            this.visualizarResultado.Location = new System.Drawing.Point(39, 375);
            this.visualizarResultado.Name = "visualizarResultado";
            this.visualizarResultado.Size = new System.Drawing.Size(679, 85);
            this.visualizarResultado.TabIndex = 4;
            this.visualizarResultado.Text = "Visualizar Resultado";
            this.visualizarResultado.UseVisualStyleBackColor = true;
            this.visualizarResultado.Click += new System.EventHandler(this.visualizarResultado_Click);
            // 
            // TelaInicial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(753, 472);
            this.Controls.Add(this.cadastrarLeilao);
            this.Controls.Add(this.fazerLance);
            this.Controls.Add(this.finalizarLeilao);
            this.Controls.Add(this.visualizarResultado);
            this.Name = "TelaInicial";
            this.Text = "Tela Inicial";
            this.Load += new System.EventHandler(this.TelaInicial_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button cadastrarLeilao;
        private System.Windows.Forms.Button fazerLance;
        private System.Windows.Forms.Button finalizarLeilao;
        private System.Windows.Forms.Button visualizarResultado;
    }
}

