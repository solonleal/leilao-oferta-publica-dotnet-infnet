﻿namespace WindowsApp
{
    partial class FazerLance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnFazerLance = new System.Windows.Forms.Button();
            this.btnVoltarTelaInicial = new System.Windows.Forms.Button();
            this.titulo = new System.Windows.Forms.ComboBox();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.qntTituloOfertado = new System.Windows.Forms.TextBox();
            this.lblQtdTituloOfertado = new System.Windows.Forms.Label();
            this.instituicao = new System.Windows.Forms.ComboBox();
            this.lblInstituicao = new System.Windows.Forms.Label();
            this.qtdTituloDesejado = new System.Windows.Forms.TextBox();
            this.lblQtdTituloDesejado = new System.Windows.Forms.Label();
            this.valorUnitarioTitulo = new System.Windows.Forms.TextBox();
            this.lblValorUnitarioTitulo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnFazerLance
            // 
            this.btnFazerLance.Location = new System.Drawing.Point(118, 258);
            this.btnFazerLance.Name = "btnFazerLance";
            this.btnFazerLance.Size = new System.Drawing.Size(168, 51);
            this.btnFazerLance.TabIndex = 4;
            this.btnFazerLance.Text = "Fazer um novo lance";
            this.btnFazerLance.UseVisualStyleBackColor = true;
            this.btnFazerLance.Click += new System.EventHandler(this.btnFazerLance_Click);
            // 
            // btnVoltarTelaInicial
            // 
            this.btnVoltarTelaInicial.Location = new System.Drawing.Point(251, 35);
            this.btnVoltarTelaInicial.Name = "btnVoltarTelaInicial";
            this.btnVoltarTelaInicial.Size = new System.Drawing.Size(59, 23);
            this.btnVoltarTelaInicial.TabIndex = 5;
            this.btnVoltarTelaInicial.Text = "Voltar";
            this.btnVoltarTelaInicial.UseVisualStyleBackColor = true;
            this.btnVoltarTelaInicial.Click += new System.EventHandler(this.btnVoltarTelaInicial_Click);
            // 
            // titulo
            // 
            this.titulo.FormattingEnabled = true;
            this.titulo.Location = new System.Drawing.Point(118, 85);
            this.titulo.Name = "titulo";
            this.titulo.Size = new System.Drawing.Size(168, 21);
            this.titulo.TabIndex = 6;
            this.titulo.SelectedIndexChanged += new System.EventHandler(this.titulo_SelectedIndexChanged);
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Location = new System.Drawing.Point(73, 89);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(35, 13);
            this.lblTitulo.TabIndex = 7;
            this.lblTitulo.Text = "Título";
            // 
            // qntTituloOfertado
            // 
            this.qntTituloOfertado.Enabled = false;
            this.qntTituloOfertado.Location = new System.Drawing.Point(118, 113);
            this.qntTituloOfertado.Name = "qntTituloOfertado";
            this.qntTituloOfertado.ReadOnly = true;
            this.qntTituloOfertado.Size = new System.Drawing.Size(168, 20);
            this.qntTituloOfertado.TabIndex = 8;
            // 
            // lblQtdTituloOfertado
            // 
            this.lblQtdTituloOfertado.AutoSize = true;
            this.lblQtdTituloOfertado.Location = new System.Drawing.Point(12, 116);
            this.lblQtdTituloOfertado.Name = "lblQtdTituloOfertado";
            this.lblQtdTituloOfertado.Size = new System.Drawing.Size(97, 13);
            this.lblQtdTituloOfertado.TabIndex = 9;
            this.lblQtdTituloOfertado.Text = "Qtd Titulo Ofertado";
            // 
            // instituicao
            // 
            this.instituicao.FormattingEnabled = true;
            this.instituicao.Location = new System.Drawing.Point(118, 145);
            this.instituicao.Name = "instituicao";
            this.instituicao.Size = new System.Drawing.Size(168, 21);
            this.instituicao.TabIndex = 10;
            // 
            // lblInstituicao
            // 
            this.lblInstituicao.AutoSize = true;
            this.lblInstituicao.Location = new System.Drawing.Point(53, 148);
            this.lblInstituicao.Name = "lblInstituicao";
            this.lblInstituicao.Size = new System.Drawing.Size(55, 13);
            this.lblInstituicao.TabIndex = 11;
            this.lblInstituicao.Text = "Instituição";
            // 
            // qtdTituloDesejado
            // 
            this.qtdTituloDesejado.Location = new System.Drawing.Point(118, 172);
            this.qtdTituloDesejado.Name = "qtdTituloDesejado";
            this.qtdTituloDesejado.Size = new System.Drawing.Size(168, 20);
            this.qtdTituloDesejado.TabIndex = 12;
            // 
            // lblQtdTituloDesejado
            // 
            this.lblQtdTituloDesejado.AutoSize = true;
            this.lblQtdTituloDesejado.Location = new System.Drawing.Point(5, 176);
            this.lblQtdTituloDesejado.Name = "lblQtdTituloDesejado";
            this.lblQtdTituloDesejado.Size = new System.Drawing.Size(103, 13);
            this.lblQtdTituloDesejado.TabIndex = 13;
            this.lblQtdTituloDesejado.Text = "Qtd Título Desejado";
            // 
            // valorUnitarioTitulo
            // 
            this.valorUnitarioTitulo.Location = new System.Drawing.Point(118, 199);
            this.valorUnitarioTitulo.Name = "valorUnitarioTitulo";
            this.valorUnitarioTitulo.Size = new System.Drawing.Size(168, 20);
            this.valorUnitarioTitulo.TabIndex = 14;
            // 
            // lblValorUnitarioTitulo
            // 
            this.lblValorUnitarioTitulo.AutoSize = true;
            this.lblValorUnitarioTitulo.Location = new System.Drawing.Point(7, 202);
            this.lblValorUnitarioTitulo.Name = "lblValorUnitarioTitulo";
            this.lblValorUnitarioTitulo.Size = new System.Drawing.Size(101, 13);
            this.lblValorUnitarioTitulo.TabIndex = 15;
            this.lblValorUnitarioTitulo.Text = "Valor Unitário Título";
            // 
            // FazerLance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(394, 379);
            this.Controls.Add(this.lblValorUnitarioTitulo);
            this.Controls.Add(this.valorUnitarioTitulo);
            this.Controls.Add(this.lblQtdTituloDesejado);
            this.Controls.Add(this.qtdTituloDesejado);
            this.Controls.Add(this.lblInstituicao);
            this.Controls.Add(this.instituicao);
            this.Controls.Add(this.lblQtdTituloOfertado);
            this.Controls.Add(this.qntTituloOfertado);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.titulo);
            this.Controls.Add(this.btnVoltarTelaInicial);
            this.Controls.Add(this.btnFazerLance);
            this.Name = "FazerLance";
            this.Text = "Fazer um lance";
            this.Load += new System.EventHandler(this.FazerLance_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnFazerLance;
        private System.Windows.Forms.Button btnVoltarTelaInicial;
        private System.Windows.Forms.ComboBox titulo;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.TextBox qntTituloOfertado;
        private System.Windows.Forms.Label lblQtdTituloOfertado;
        private System.Windows.Forms.ComboBox instituicao;
        private System.Windows.Forms.Label lblInstituicao;
        private System.Windows.Forms.TextBox qtdTituloDesejado;
        private System.Windows.Forms.Label lblQtdTituloDesejado;
        private System.Windows.Forms.TextBox valorUnitarioTitulo;
        private System.Windows.Forms.Label lblValorUnitarioTitulo;
    }
}