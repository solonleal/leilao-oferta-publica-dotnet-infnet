﻿namespace WindowsApp
{
    partial class FazerLance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnFazerLance = new System.Windows.Forms.Button();
            this.btnVoltarTelaInicial = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnAdicionarNovoTitulo
            // 
            this.btnFazerLance.Location = new System.Drawing.Point(118, 258);
            this.btnFazerLance.Name = "btnFazerLance";
            this.btnFazerLance.Size = new System.Drawing.Size(168, 51);
            this.btnFazerLance.TabIndex = 4;
            this.btnFazerLance.Text = "Fazer um novo lance";
            this.btnFazerLance.UseVisualStyleBackColor = true;
            this.btnFazerLance.Click += new System.EventHandler(this.btnFazerLance_Click);
            // 
            // btnVoltarTelaInicial
            // 
            this.btnVoltarTelaInicial.Location = new System.Drawing.Point(251, 35);
            this.btnVoltarTelaInicial.Name = "btnVoltarTelaInicial";
            this.btnVoltarTelaInicial.Size = new System.Drawing.Size(59, 23);
            this.btnVoltarTelaInicial.TabIndex = 5;
            this.btnVoltarTelaInicial.Text = "Voltar";
            this.btnVoltarTelaInicial.UseVisualStyleBackColor = true;
            this.btnVoltarTelaInicial.Click += new System.EventHandler(this.btnVoltarTelaInicial_Click);
            // 
            // FazerLance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(394, 379);
            this.Controls.Add(this.btnVoltarTelaInicial);
            this.Controls.Add(this.btnFazerLance);
            this.Name = "FazerLance";
            this.Text = "Fazer um lance";
            this.Load += new System.EventHandler(this.FazerLance_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnFazerLance;
        private System.Windows.Forms.Button btnVoltarTelaInicial;
    }
}