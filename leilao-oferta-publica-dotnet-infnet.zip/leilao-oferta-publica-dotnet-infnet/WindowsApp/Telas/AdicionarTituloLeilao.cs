﻿using DomainModel;
using DomainModel.Entities;
using DomainModel.Entities.LeilaoAggregate;
using DomainModel.Interfaces.Repositories;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsApp.Util;

namespace WindowsApp
{
    public partial class AdicionarTituloLeilao : Form
    {
        public List<LeilaoOferta> Ofertas { get; set; }

        public AdicionarTituloLeilao(List<LeilaoOferta> Ofertas)
        {
            InitializeComponent();

            this.Ofertas = Ofertas;
        }

        private void btnAdicionarNovoTitulo_Click(object sender, EventArgs e)
        {
            var titulo = ((ComboBoxItem)titulos.SelectedItem).Value;
            var quantidade = quantidadeTitulo.Text;

            var leilaoOferta = new LeilaoOferta();
            leilaoOferta.Quantidade = long.Parse(quantidade);
            leilaoOferta.Titulo = GetTitulos().Find(t => t.Id == titulo);


            Ofertas.Add(leilaoOferta);

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnVoltarTelaInicial_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void AdicionarTituloLeilao_Load(object sender, EventArgs e)
        {
            foreach (var tituloItem in GetTitulos())
            {
                ComboBoxItem item = new ComboBoxItem(tituloItem.Name(), tituloItem.Id);
                titulos.Items.Add(item);
            }
        }

        private List<Titulo> GetTitulos()
        {
            var fabricaServicoRemoto = new FabricaServicoRemoto();

            var servicoRemoto = fabricaServicoRemoto.GetServicoLeilaoWCF();
            var tituloList = servicoRemoto.GetTitulos();

            fabricaServicoRemoto.CloseServicoLeilaoWCF();

            return tituloList;
        }

    }
}
