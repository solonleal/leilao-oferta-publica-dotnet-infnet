﻿using DomainModel;
using DomainModel.Entities;
using DomainModel.Entities.Instituicao;
using DomainModel.Entities.LeilaoAggregate;
using DomainModel.Interfaces.Repositories;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsApp.Util;

namespace WindowsApp
{
    public partial class FazerLance : Form
    {
        public FazerLance()
        {
            InitializeComponent();
        }

        private void btnFazerLance_Click(object sender, EventArgs e)
        {

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnVoltarTelaInicial_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FazerLance_Load(object sender, EventArgs e)
        {
            foreach (var instituicaoItem in GetInstituicoes())
            {
                ComboBoxItem item = new ComboBoxItem(instituicaoItem.GetNomeCompleto(), instituicaoItem.Id);
                instituicao.Items.Add(item);
            }

            List<Titulo> tituloList = new List<Titulo>();
            foreach (var ofertaItem in GetOfertas())
            {
                tituloList.Add(ofertaItem.Titulo);
            }

            foreach (var tituloItem in tituloList)
            {
                ComboBoxItem item = new ComboBoxItem(tituloItem.Name(), tituloItem.Id);
                titulo.Items.Add(item);
            }
        }

        private List<LeilaoOferta> GetOfertas()
        {
            var fabricaServicoRemoto = new FabricaServicoRemoto();

            var servicoRemoto = fabricaServicoRemoto.GetServicoLeilaoWCF();
            var ofertaList = servicoRemoto.GetOfertas();

            fabricaServicoRemoto.CloseServicoLeilaoWCF();

            return ofertaList;
        }

        private List<Instituicao> GetInstituicoes()
        {
            var fabricaServicoRemoto = new FabricaServicoRemoto();

            var servicoRemoto = fabricaServicoRemoto.GetServicoLeilaoWCF();
            var instituicaoList = servicoRemoto.GetInstituicoes();

            fabricaServicoRemoto.CloseServicoLeilaoWCF();

            return instituicaoList;
        }

        private void titulo_SelectedIndexChanged(object sender, EventArgs e)
        {
            var tituloSelecionado = ((ComboBoxItem)titulo.SelectedItem).Value;

            LeilaoOferta ofertaSelecionada = GetOfertas().Find(o => o.Titulo.Id == tituloSelecionado);
            qntTituloOfertado.Text = ofertaSelecionada.Quantidade.ToString();
        }
    }
}
