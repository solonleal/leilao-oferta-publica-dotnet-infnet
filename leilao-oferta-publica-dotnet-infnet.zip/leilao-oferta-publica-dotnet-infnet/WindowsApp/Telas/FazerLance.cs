﻿using DomainModel;
using DomainModel.Entities;
using DomainModel.Entities.LeilaoAggregate;
using DomainModel.Interfaces.Repositories;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsApp.Util;

namespace WindowsApp
{
    public partial class FazerLance : Form
    {
        public List<LeilaoOferta> Ofertas { get; set; }

        public FazerLance(List<LeilaoOferta> Ofertas)
        {
            InitializeComponent();

            this.Ofertas = Ofertas;
        }

        private void btnFazerLance_Click(object sender, EventArgs e)
        {

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnVoltarTelaInicial_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FazerLance_Load(object sender, EventArgs e)
        {
        }

    }
}
