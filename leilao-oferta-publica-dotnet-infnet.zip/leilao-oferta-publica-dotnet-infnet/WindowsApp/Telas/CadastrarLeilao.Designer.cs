﻿namespace WindowsApp
{
    partial class CadastrarLeilao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.voltarTelaInicial = new System.Windows.Forms.Button();
            this.numeroPortaria = new System.Windows.Forms.TextBox();
            this.lblNumeroPortaria = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dataHoraLeilao = new System.Windows.Forms.Label();
            this.btnCadastrarLeilao = new System.Windows.Forms.Button();
            this.ofertasList = new System.Windows.Forms.ListView();
            this.adicionarTituloLeilao = new System.Windows.Forms.Button();
            this.lblTitulos = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // voltarTelaInicial
            // 
            this.voltarTelaInicial.Location = new System.Drawing.Point(294, 21);
            this.voltarTelaInicial.Name = "voltarTelaInicial";
            this.voltarTelaInicial.Size = new System.Drawing.Size(73, 23);
            this.voltarTelaInicial.TabIndex = 0;
            this.voltarTelaInicial.Text = "Voltar";
            this.voltarTelaInicial.UseVisualStyleBackColor = true;
            this.voltarTelaInicial.Click += new System.EventHandler(this.voltarTelaInicial_Click);
            // 
            // numeroPortaria
            // 
            this.numeroPortaria.Location = new System.Drawing.Point(139, 103);
            this.numeroPortaria.Name = "numeroPortaria";
            this.numeroPortaria.Size = new System.Drawing.Size(228, 20);
            this.numeroPortaria.TabIndex = 1;
            // 
            // lblNumeroPortaria
            // 
            this.lblNumeroPortaria.AutoSize = true;
            this.lblNumeroPortaria.Location = new System.Drawing.Point(90, 106);
            this.lblNumeroPortaria.Name = "lblNumeroPortaria";
            this.lblNumeroPortaria.Size = new System.Drawing.Size(43, 13);
            this.lblNumeroPortaria.TabIndex = 2;
            this.lblNumeroPortaria.Text = "Portaria";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(139, 139);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(228, 20);
            this.dateTimePicker1.TabIndex = 3;
            // 
            // dataHoraLeilao
            // 
            this.dataHoraLeilao.AutoSize = true;
            this.dataHoraLeilao.Location = new System.Drawing.Point(31, 145);
            this.dataHoraLeilao.Name = "dataHoraLeilao";
            this.dataHoraLeilao.Size = new System.Drawing.Size(102, 13);
            this.dataHoraLeilao.TabIndex = 4;
            this.dataHoraLeilao.Text = "Data Hora do Leilão";
            // 
            // btnCadastrarLeilao
            // 
            this.btnCadastrarLeilao.Location = new System.Drawing.Point(139, 355);
            this.btnCadastrarLeilao.Name = "btnCadastrarLeilao";
            this.btnCadastrarLeilao.Size = new System.Drawing.Size(228, 43);
            this.btnCadastrarLeilao.TabIndex = 5;
            this.btnCadastrarLeilao.Text = "Cadastrar Novo Leilão";
            this.btnCadastrarLeilao.UseVisualStyleBackColor = true;
            this.btnCadastrarLeilao.Click += new System.EventHandler(this.btnCadastrarLeilao_Click);
            // 
            // ofertas
            // 
            this.ofertasList.Location = new System.Drawing.Point(139, 187);
            this.ofertasList.Name = "ofertas";
            this.ofertasList.Size = new System.Drawing.Size(228, 94);
            this.ofertasList.TabIndex = 6;
            this.ofertasList.UseCompatibleStateImageBehavior = false;
            // 
            // adicionarTituloLeilao
            // 
            this.adicionarTituloLeilao.Location = new System.Drawing.Point(139, 287);
            this.adicionarTituloLeilao.Name = "adicionarTituloLeilao";
            this.adicionarTituloLeilao.Size = new System.Drawing.Size(228, 23);
            this.adicionarTituloLeilao.TabIndex = 7;
            this.adicionarTituloLeilao.Text = "Adicionar Titulo Leilão";
            this.adicionarTituloLeilao.UseVisualStyleBackColor = true;
            this.adicionarTituloLeilao.Click += new System.EventHandler(this.adicionarTituloLeilao_Click);
            // 
            // lblTitulos
            // 
            this.lblTitulos.AutoSize = true;
            this.lblTitulos.Location = new System.Drawing.Point(90, 187);
            this.lblTitulos.Name = "lblTitulos";
            this.lblTitulos.Size = new System.Drawing.Size(38, 13);
            this.lblTitulos.TabIndex = 8;
            this.lblTitulos.Text = "Titulos";
            // 
            // CadastrarLeilao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(457, 463);
            this.Controls.Add(this.lblTitulos);
            this.Controls.Add(this.adicionarTituloLeilao);
            this.Controls.Add(this.ofertasList);
            this.Controls.Add(this.btnCadastrarLeilao);
            this.Controls.Add(this.dataHoraLeilao);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.lblNumeroPortaria);
            this.Controls.Add(this.numeroPortaria);
            this.Controls.Add(this.voltarTelaInicial);
            this.Name = "CadastrarLeilao";
            this.Text = "Cadastrar Leilão";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button voltarTelaInicial;
        private System.Windows.Forms.TextBox numeroPortaria;
        private System.Windows.Forms.Label lblNumeroPortaria;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label dataHoraLeilao;
        private System.Windows.Forms.Button btnCadastrarLeilao;
        private System.Windows.Forms.ListView ofertasList;
        private System.Windows.Forms.Button adicionarTituloLeilao;
        private System.Windows.Forms.Label lblTitulos;
    }
}