﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsApp
{
    public partial class TelaInicial : Form
    {
        public TelaInicial()
        {
            InitializeComponent();
        }

        private void TelaInicial_Load(object sender, EventArgs e)
        {
        }

        private void cadastrarLeilao_Click(object sender, EventArgs e)
        {
            new CadastrarLeilao().ShowDialog();
        }

        private void fazerLance_Click(object sender, EventArgs e)
        {
            new FazerLance().ShowDialog();
        }

        private void finalizarLeilao_Click(object sender, EventArgs e)
        {

        }

        private void visualizarResultado_Click(object sender, EventArgs e)
        {

        }
    }
}
