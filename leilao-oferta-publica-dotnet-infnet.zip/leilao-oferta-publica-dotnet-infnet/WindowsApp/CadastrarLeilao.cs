﻿using DomainModel;
using DomainModel.Entities.LeilaoAggregate;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsApp
{
    public partial class CadastrarLeilao : Form
    {
        public List<LeilaoOferta> Ofertas { get; set; }

        public Leilao Leilao { get; set; }

        public CadastrarLeilao()
        {
            Ofertas = new List<LeilaoOferta>();

            InitializeComponent();

            RefreshListaOfertas();
        }

        private void voltarTelaInicial_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void adicionarTituloLeilao_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = new AdicionarTituloLeilao(Ofertas).ShowDialog();
            if (dialogResult.Equals(DialogResult.OK))
                RefreshListaOfertas();
        }

        private void btnCadastrarLeilao_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void RefreshListaOfertas()
        {
            ofertasList.Items.Clear();

            foreach(var oferta in Ofertas)
            {
                ofertasList.Items.Add(oferta.ToString());
            }
        }

    }
}
