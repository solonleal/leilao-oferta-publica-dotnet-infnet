﻿using DomainModel;
using DomainModel.Entities.LeilaoAggregate;
using DomainModel.Interfaces.Repositories;
using DomainModel.Interfaces.Services;
using DomainService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace WcfServiceApp
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class ServicoLeilaoWCF : IServicoLeilaoWCF
    {
        IServicoInicializarEntidades servicoInicializarEntidades = new ServicoInicializarEntidade();
        IServicoCadastrarLeilao servicoCadastrarLeilao = new ServicoCadastrarLeilao();

        public void InicializarEntidades()
        {
            servicoInicializarEntidades.InicializarEntidades();
        }

        public List<Titulo> GetTitulos()
        {
            return servicoCadastrarLeilao.GetTitulos();
        }

        public void CadastrarLeilao(Leilao novoLeilao)
        {
            servicoCadastrarLeilao.CadastrarLeilao(novoLeilao);
        }
    }
}
